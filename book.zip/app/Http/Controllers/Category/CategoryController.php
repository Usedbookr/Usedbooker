<?php

namespace App\Http\Controllers\Category;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use Auth;
use File;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;


class CategoryController extends Controller
{
    public function All(){
        
        $categories = Category::Where('level',1)->Where('parent_id',0)->latest()->get();
        return view('backend.category.all',compact('categories'));
    } // End Method 


    
    Public function ApiAll(){
        $categories = Category::Where('level',1)->Where('parent_id',0)->Where('status',1)->get();
        if($categories->isNotEmpty()){
            foreach($categories as $catlists){
                $catlists->images = asset($catlists->images);
            }
        }
        return response([
            'success' => true,
            'categories' => $categories
        ]);
        //return view('backend.category.all',compact('categories'));
    }


    public function Add(){
     return view('backend.category.add');
    } // End Method 


    public function Store(Request $request){

        $imageName = '';
        if($request->hasFile('userfile')){
            $imageName = time().'.'.$request->userfile->extension(); 
            $request->userfile->move(public_path('upload/admin_images/category'), $imageName); 
        }
        
        $str = strtolower($request->name);
        Category::insert([
            'name' => $request->name,
            'status' =>$request->status,
            'best_seller' =>$request->section_id ?? 'off',
            'cod_disable' =>$request->cod_disable ?? 'off',
            'before_content' =>$request->before_content,
            'parent_id' =>0,
            'level' =>1,
            'url_slug' =>$request->url_slug,
            'images' => 'public/upload/admin_images/category/'.$imageName,
            'created_by' => Auth::user()->id,
            'created_at' => Carbon::now(), 
            'meta_name' => $request->meta_name,
            'meta_description' => $request->meta_description,
            'meta_keyword' => $request->meta_keyword,
        ]);

         $notification = array(
            'message' => 'Category Inserted Successfully', 
            'alert-type' => 'success'
        );

        return redirect()->route('categories.all')->with($notification);

    } // End Method 


    public function Edit($id){

        $edit = Category::findOrFail($id);
        return view('backend.category.edit',compact('edit'));

    } // End Method 

    public function Update(Request $request){
    
        $id = $request->id;
        if($request->hasFile('userfile'))
        {

            $image_path = Category::where('id', $id)->first();
            $filePath = $image_path->images;
                                       
            if(File::exists($filePath))
            {
                File::delete($filePath);
            }
            else
            {
                // dd("hlo");
            }

            $imageName = time().'.'.$request->userfile->extension(); 
            $request->userfile->move(public_path('upload/admin_images/category'), $imageName); 
            Category::findOrFail($id)->update([
                'images' => 'public/upload/admin_images/category/'.$imageName,
                'updated_by' => Auth::user()->id,
                'updated_at' => Carbon::now(), 
    
            ]);
        }
        
        $str = strtolower($request->name);
        
        // dd($request->section_id);
        Category::findOrFail($id)->update([
            'name' => $request->name,
            'status' => $request->status,
            'best_seller' =>$request->section_id ?? 'off',
            'before_content' =>$request->before_content ?? 'off',
            'cod_disable' =>$request->cod_disable ?? 'off',
            'parent_id' =>0,
            'level' =>1,
            'url_slug' =>$request->url_slug,
            'updated_by' => Auth::user()->id,
            'updated_at' => Carbon::now(), 
            'meta_name' => $request->meta_name,
            'meta_description' => $request->meta_description,
            'meta_keyword' => $request->meta_keyword,

        ]);

         $notification = array(
            'message' => ' Updated Successfully', 
            'alert-type' => 'success'
        );

        return redirect()->route('categories.all')->with($notification);

    } // End Method 


    public function Delete($id)
    {

        $image_path = Category::where('id', $id)->first();
        $filePath = $image_path->images;
                                   
        if(File::exists($filePath))
        {
            File::delete($filePath);
        }
        else
        {
            // dd("hlo");
        }

        Category::findOrFail($id)->delete();
        $notification = array(
            'message' => 'Deleted Successfully', 
            'alert-type' => 'success'
        );
        return redirect()->back()->with($notification);
    } // End Method
    

    public function FetchBook()
    {
        try{
            // $url = 'https://api2.isbndb.com/book/935010587X';  
            // $restKey = '50363_9a77755a173b1d79066197d0ce1bf427';  
            
            // $headers = array(  
            //   "Content-Type: application/json",  
            //   "Authorization: " . $restKey  
            // ); 
            
            // $author = rawurlencode('Disha Experts');
            // $url = "https://api2.isbndb.com/author/{$author}";  
            // $restKey = '50363_9a77755a173b1d79066197d0ce1bf427';  

            $url = "https://api2.isbndb.com/books/isbn";  
            $restKey = env('REST_KEY');  
            
            $headers = array(  
              "Content-Type: application/json",  
              "Authorization: " . $restKey  
            );  
            
          
            
            $rest = curl_init();  
            curl_setopt($rest,CURLOPT_URL,$url);  
            curl_setopt($rest,CURLOPT_HTTPHEADER,$headers);  
            curl_setopt($rest,CURLOPT_RETURNTRANSFER, true);  
            
            $response = curl_exec($rest);
            $jsonResponse = json_decode($response, true);
            //dd($jsonResponse);
            
            return response([
                'success' => true,
                'response' => $jsonResponse
            ]);
            
        }catch (Exception $exception) {
            return response([
                'success' => false,
                'generalerror' => true,
                'message' => $exception->getMessage()
            ]);
        }
       
        // $response;  
        //print_r($response);  
        //curl_close($rest);
    }



    public function FetchAuthors()
    {
        try{
            // $url = 'https://api2.isbndb.com/book/935010587X';  
            // $restKey = '50363_9a77755a173b1d79066197d0ce1bf427';  
            
            // $headers = array(  
            //   "Content-Type: application/json",  
            //   "Authorization: " . $restKey  
            // ); 
            
            $author = rawurlencode('Disha Experts');
            $url = "https://api2.isbndb.com/author/{$author}";  
            $restKey = env('REST_KEY');  

            // $url = "https://api2.isbndb.com/books/isbn";  
            // $restKey = '50363_9a77755a173b1d79066197d0ce1bf427';  
            
            $headers = array(  
              "Content-Type: application/json",  
              "Authorization: " . $restKey  
            );  
            
          
            
            $rest = curl_init();  
            curl_setopt($rest,CURLOPT_URL,$url);  
            curl_setopt($rest,CURLOPT_HTTPHEADER,$headers);  
            curl_setopt($rest,CURLOPT_RETURNTRANSFER, true);  
            
            $response = curl_exec($rest);
            $jsonResponse = json_decode($response, true);
            
            return response([
                'success' => true,
                'response' => $jsonResponse
            ]);
            
        }catch (Exception $exception) {
            return response([
                'success' => false,
                'generalerror' => true,
                'message' => $exception->getMessage()
            ]);
        }
       
        // $response;  
        //print_r($response);  
        //curl_close($rest);
    }


    
}
